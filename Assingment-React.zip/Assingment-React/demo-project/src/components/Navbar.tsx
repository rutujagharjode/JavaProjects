
// import React from 'react'
// import './Homepage.css';

// const Navbar: React.FC<{}> = () => {
//   return (
//     <div>
//       {/* Write your code here to create a navbar with Logo and two tabs:
//       1- Home
//       2- Search
//       Implement the concept of react routing as well */}
//     </div>
//   )
// }

// export default Navbar

// import React from 'react';
// import { Link } from 'react-router-dom';
// import './Homepage.css';
// import "./Navbar.css";
// // import logo from '../assets/github_new.webp';
// import logo from "../assests/logo_git.png";

// const Navbar: React.FC<{}> = () => {
//   return (
//     <nav>
//     <div className="navbar">
//       <div className="logo-container">
//         <Link to="/">
//           <img src={logo} alt="Logo" />
//           Logo
//         </Link>
//       </div>
//       <div className="links-container">
//         <Link to="/" className="links">
//           Home
//         </Link>
//         <Link to="/search" className="links">
//           Search
//         </Link>
//       </div>
//     </div>
//     </nav>
//   );
// };

// export default Navbar;

import React from "react";
import "./Homepage.css";
import "./Navbar.css";
import logo from "../assests/logo_git.png";

const Navbar: React.FC<{}> = () => {
  return (
    <nav>
      <img src={logo} alt="" />
      <div className="space"></div>
      <a href="/">Home</a>
      <a href="/search">Search</a>
    </nav>
  );
};

export default Navbar;
